//<![CDATA[
//prepare the form when the DOM is ready
$(document).ready(function() {
    var options = {
        target:        '#output-message',   // target element(s) to be updated with server response
        beforeSubmit:  showRequest,  // pre-submit callback
        success:       showResponse  // post-submit callback

        // other available options:
        //url:       url         // override for form's 'action' attribute
        //type:      type        // 'get' or 'post', override for form's 'method' attribute
        //dataType:  null        // 'xml', 'script', or 'json' (expected server response type)
        //clearForm: true        // clear all form fields after successful submit
        //resetForm: true        // reset the form after successful submit

        // $.ajax options can be used here too, for example:
        //timeout:   3000
    };

    $("#contact-form").validate();
    // bind form using 'ajaxForm'
    $('#contact-form').ajaxForm(options);
});

// pre-submit callback
function showRequest(formData, jqForm, options) {
    // formData is an array; here we use $.param to convert it to a string to display it
    // but the form plugin does this for you automatically when it submits the data
    var queryString = $.param(formData);

    // jqForm is a jQuery object encapsulating the form element.  To access the
    // DOM element for the form do this:
    // var formElement = jqForm[0];

	if(confirm('You are about to send the information below to Destiny Kids Library. Please confirm... \n\n Name: ' + $("#ContactName").val()
		+ '\n\n Email: ' + $("#ContactEmail").val()
		+ '\n\n Phone: ' + $("#ContactPhone").val()
		+ '\n\n Subject: ' + $("#ContactSubject").val()
		+ '\n\n Message: ' + $("#ContactMessage").val()
	+ '')){
        return true;
    }else {
        // here we could return false to prevent the form from being submitted;
        // returning anything other than false will allow the form submit to continue
        return false;
    }
}

// post-submit callback
function showResponse(responseText, statusText, xhr, $form)  {
    // for normal html responses, the first argument to the success callback
    // is the XMLHttpRequest object's responseText property

    // if the ajaxForm method was passed an Options Object with the dataType
    // property set to 'xml' then the first argument to the success callback
    // is the XMLHttpRequest object's responseXML property

    // if the ajaxForm method was passed an Options Object with the dataType
    // property set to 'json' then the first argument to the success callback
    // is the json data object returned by the server

    //alert('status: ' + statusText + '\n\nresponseText: \n' + responseText +
      //  '\n\nThe output div should have already been updated with the responseText.');
      $('#output-message').css('display', 'block');
	  //$("#output-message").html('<br />' + responseText);
      $('#contact-form').get(0).reset();
}
//]]>

var div = $("div.ball");
var span = $("div.ball span");

span.width(Math.sqrt(span.width() * span.height()));
span.width(Math.sqrt(span.width() * span.height()));
div.width(Math.sqrt(2) * span.width());
div.height(div.width());

$('document').ready(function(){
	$("a.start").click(function(e){
		e.preventDefault();
	    $('html, body').animate({scrollTop: $("#start").offset().top -100}, 500);
	});
	
	$('.photo-gallery').fancybox({
		padding : 0,
		helpers : {
			thumbs : {
				width  : 50,
				height : 50
			},
			overlay: {
			    locked: true
			}
		}
	});
	
	$('.tlt').textillate({
	  // the default selector to use when detecting multiple texts to animate
	  selector: '.texts',
  
	  // enable looping
	  loop: true,
  
	  // sets the minimum display time for each text before it is replaced
	  minDisplayTime: 2000,
  
	  // sets the initial delay before starting the animation
	  // (note that depending on the in effect you may need to manually apply 
	  // visibility: hidden to the element before running this plugin)
	  initialDelay: 1000,
    
	  // set whether or not to automatically start animating
	  autoStart: true,
  
	  // custom set of 'in' effects. This effects whether or not the 
	  // character is shown/hidden before or after an animation  
	  inEffects: ['swing'],
  
	  // custom set of 'out' effects
	  outEffects: [ 'hinge' ],
  
	  // in animation settings
	  in: {
	  	// set the effect name
	    effect: 'swing',
    
	    // set the delay factor applied to each consecutive character
	    delayScale: 2,
    
	    // set the delay between each character
	    delay: 80,
    
	    // set to true to animate all the characters at the same time
	    sync: false,
    
	    // randomize the character sequence 
	    // (note that shuffle doesn't make sense with sync = true)
	    shuffle: false,

	    // reverse the character sequence 
	    // (note that reverse doesn't make sense with sync = true)
	    reverse: false,

	    // callback that executes once the animation has finished
	    callback: function () {}
	  },
  
	  // out animation settings.
	  out: {
	    effect: 'hinge',
	    delayScale: 2,
	    delay: 80,
	    sync: false,
	    shuffle: false,
	    reverse: false,
	    callback: function () {}
	  },

	  // callback that executes once textillate has finished 
	  callback: function () {},

	  // set the type of token to animate (available types: 'char' and 'word')
	  type: 'char'
	});
});

$(document).foundation();